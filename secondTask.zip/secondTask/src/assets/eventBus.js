
// 创建中央事件总线,承担起了组件之间通信的桥梁
import Vue from 'Vue'

export default new Vue;